﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Unnoti.Core.DTOs;
using Unnoti.Core.Logging;

namespace Unnoti.Core.Services
{
    public class GoldenRecordImportService
    {
        private readonly HttpClient _client;
        private readonly LogService _logger;

        public GoldenRecordImportService(string baseUrl, LogService logger)
        {
            _logger = logger;
            _client = new HttpClient
            {
                BaseAddress = new Uri(baseUrl)
            };
        }

        public GoldenRecordImportService(string baseUrl,string apiKey)
        {
            _client = new HttpClient
            {
                BaseAddress = new Uri(baseUrl)
            };
        }

        public async Task SendAsync(GoldenRecordPayload payload,CancellationToken cancellationToken)
        {
            var json = JsonConvert.SerializeObject(payload);

            var resp = await _client.PostAsync(
                "/ingest",
                new StringContent(json, Encoding.UTF8, "application/json"));

            if (!resp.IsSuccessStatusCode)
            {
                var err = await resp.Content.ReadAsStringAsync();
                _logger.Error(err);
                throw new Exception(err);
            }
        }
    }
}
